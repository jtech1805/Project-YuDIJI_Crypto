import { Router, type NextFunction, type Request, type Response } from "express";
import { z } from "zod";

import {
  createMonitor,
  deleteMonitor,
  getSymbols,
  getUserMonitors,
  debugEngineState,
  searchUniversalSymbols,
  updateMonitor
} from "../controllers/monitor.controller.js";
import { AppError } from "../errors/AppError.js";
import { asyncHandler } from "../middlewares/errorHandler.js";
import { requireAuth } from "../middlewares/requireAuth.js";

const monitorRouter = Router();

const createMonitorSchema = z.object({
  symbolId: z.string().min(1).optional(),
  symbol: z.string().min(1).optional(),
  thresholdPercentage: z.number().positive().max(100),
  timeWindowMinutes: z.number().int().positive().max(24 * 60),
  trigger: z.string().min(1).max(10),
  provider: z.string().optional(),
  exchange: z.string().optional(),
  instrumentToken: z.string().optional(),
}).refine((value) => Boolean(value.symbolId || value.symbol), {
  message: "symbolId or symbol is required",
});

const validateBody =
  <T extends z.ZodType>(schema: T) =>
    (req: Request, _res: Response, next: NextFunction): void => {
      const parsedBody = schema.safeParse(req.body);
      if (!parsedBody.success) {
        next(new AppError("Invalid request body", 400));
        return;
      }

      req.body = parsedBody.data;
      next();
    };

monitorRouter.get("/symbols", asyncHandler(getSymbols));
monitorRouter.get("/symbols/universal", asyncHandler(searchUniversalSymbols));
monitorRouter.get("/", requireAuth, asyncHandler(getUserMonitors));
monitorRouter.post("/", requireAuth, validateBody(createMonitorSchema), asyncHandler(createMonitor));
monitorRouter.patch("/:id", requireAuth, asyncHandler(updateMonitor));
monitorRouter.delete("/:id", requireAuth, asyncHandler(deleteMonitor));
monitorRouter.get('/debug/engine-state', requireAuth, asyncHandler(debugEngineState))

export { monitorRouter };
